# REDUX

## 1. Instalar dependências
## 2. Gravar

## 3. REDUX
```
yarn add react-redux
yarn add redux-persist
```

## 4. Criar store / action
    - cart

## 5. rootReduccer

## 6. configurar index da store

## 7. Configurar o App.js

## 8. Criar componente Card Produto

## 9. Alterar Home para inserir o Card, Totalizar, limpar o carrinho

## 10. Login e rotas protegidas

## 11. Implementar Store do usuario

## 12. Implementar Wrapper

## 13. Implementar login

## 14. Testar Persisted Reducer

## 15. Implementar página User