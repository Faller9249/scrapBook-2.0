import React from 'react';

export default function Home() {    
    return (
        <React.Fragment>
            <h1>Home</h1>
        </React.Fragment>
    );
}