import api from './api';

class Scrap {
    async getScraps() {
        const response = await api.get('scraps');

        return response.data;
    }
}

export default new Scrap();